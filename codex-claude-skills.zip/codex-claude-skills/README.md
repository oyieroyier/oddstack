# Codex Claude Skills

This bundle contains five project-local collaboration skills:

- `codex-implementation` — delegates implementation and investigation work to Codex CLI with self-contained prompts.
- `codex-review` — performs adversarial, read-only reviews of diffs, plans, branches, commits, and Codex-generated patches.
- `codex-computer-use` — prepares scoped GUI/browser/screenshot/desktop-app QA tasks for Codex Computer Use, Browser use, Chrome, image inputs, or safe local browser automation.
- `ui-nitpicker` — a ruthlessly exacting design-engineer persona (Apple/Airbnb/Stripe pedigree) for UI reviews, design-spec enforcement, journey/flow critique, and plan-first frontend implementation. Willing to radically restructure layouts and paradigms; blocks on design-spec deviations and frontend anti-patterns.
- `delegate-frontend-to-claude` — lets Codex hand a bounded frontend slice to Claude Code and resume the work through a durable, bidirectional backlog.

## Directory layout

```text
.claude/skills/
  codex-implementation/
    SKILL.md
    references/
      implementation-prompt-template.md
      validation-and-handoff.md
  codex-review/
    SKILL.md
    references/
      adversarial-review-guide.md
      review-prompt-template.md
      severity-rubric.md
  codex-computer-use/
    SKILL.md
    references/
      browser-ui-checklist.md
      computer-use-prompt-template.md
      safety-state-and-observation.md
  ui-nitpicker/
    SKILL.md
    references/
      design-review-rubric.md
      intuition-and-flow.md
      frontend-standards.md
      plan-template.md
.agents/skills/
  delegate-frontend-to-claude/
    SKILL.md
    agents/
      openai.yaml
    references/
      delegation-backlog-template.md
      frontend-handoff-template.md
    scripts/
      run-claude-frontend.sh
CLAUDE.md.codex-skills-snippet.md
install.sh
```

## Install into a project

From the extracted bundle directory:

```bash
./install.sh /path/to/your/repo
```

Or copy manually:

```bash
mkdir -p /path/to/your/repo/.claude/skills /path/to/your/repo/.agents/skills
cp -R .claude/skills/* /path/to/your/repo/.claude/skills/
cp -R .agents/skills/* /path/to/your/repo/.agents/skills/
```

Then copy the contents of `CLAUDE.md.codex-skills-snippet.md` into the repo's `CLAUDE.md` if you want the repository instructions to reference these skills explicitly.

## Install globally for your user

```bash
mkdir -p ~/.claude/skills ~/.agents/skills
cp -R .claude/skills/* ~/.claude/skills/
cp -R .agents/skills/* ~/.agents/skills/
```

Project-local install is usually safer because the behavior is scoped to a repository and can be versioned with the project.

## Verify

```bash
find .claude/skills -maxdepth 2 -name SKILL.md -print
find .agents/skills -maxdepth 2 -name SKILL.md -print
```

Expected:

```text
.claude/skills/codex-implementation/SKILL.md
.claude/skills/codex-review/SKILL.md
.claude/skills/codex-computer-use/SKILL.md
.claude/skills/ui-nitpicker/SKILL.md
.agents/skills/delegate-frontend-to-claude/SKILL.md
```

Also verify that Codex is available:

```bash
command -v codex
codex --version
codex exec --help | sed -n '1,80p'
```

## Usage examples

Ask Claude Code:

```text
Use codex-implementation to implement the narrowest fix for this bug, then inspect the diff yourself.
```

```text
Use codex-review adversarially on my uncommitted changes. Block on correctness, security, migration, or compatibility issues.
```

```text
Use codex-computer-use to prepare a scoped browser QA pass for the local checkout flow. Do not touch production or billing actions.
```

```text
Use ui-nitpicker to review this dashboard screenshot against our design spec, then plan the redesign before touching code.
```

Ask Codex:

```text
Use delegate-frontend-to-claude to implement the backend contract, delegate the bounded frontend slice to Claude, and verify the integrated result.
```

## Notes

These skills are prompt wrappers around the Codex and Claude Code CLIs and Codex app/browser workflows. They do not install either CLI, grant permissions, or bypass sandboxing. They are designed to make cross-model delegation prompts explicit, repeatable, resumable, and reviewable.
