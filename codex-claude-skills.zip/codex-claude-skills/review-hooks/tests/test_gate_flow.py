"""Decision-flow tests through the public review-gate command."""

import json
import os
import re
import shutil
import stat
import time
import unittest

from gate_test_util import (
    BLOCKING_RESULT,
    MODULE_ROOT,
    GateTestCase,
    INCONCLUSIVE_RESULT,
    MERGE_WITH_FIXES_RESULT,
    SAFE_RESULT,
    cli_envelope,
    error_envelope,
    result_script,
)

FIXTURES_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "fixtures", "claude-cli"
)


class TestSafeFlow(GateTestCase):
    def test_preflight_then_verify_push_makes_one_call(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        review = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(review.returncode, 0, review.stderr)
        self.assertEqual(self.call_count(), 1)
        self.assertEqual(len(self.cache_entries()), 1)

        verify = self.run_gate(
            "check-push",
            "--updates-file", self.updates_file(head, base),
            "--mode", "verify",
        )
        self.assertEqual(verify.returncode, 0, verify.stderr)
        self.assertEqual(self.call_count(), 1, "verify must not call the reviewer")
        self.assertIn("cache hit", verify.stdout)

    def test_verify_mode_without_decision_refuses_and_never_calls(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake, extra="AI_REVIEW_PUSH_MODE=verify\n")
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        verify = self.run_gate(
            "check-push", "--updates-file", self.updates_file(head, base)
        )
        self.assertEqual(verify.returncode, 2)
        self.assertEqual(self.call_count(), 0)
        self.assertIn("review --base", verify.stderr)
        record = self.latest_run_record()
        self.assertEqual(
            record["decision"]["reason_code"], "verify_no_decision"
        )

    def test_safe_run_writes_evidence_and_report(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 0, result.stderr)
        record = self.latest_run_record()
        self.assertEqual(record["decision"]["verdict"], "SAFE")
        self.assertEqual(record["base"], base)
        self.assertEqual(record["head"], head)
        self.assertIn("reviewer_identity", record)
        self.assertIn("prompt_digest", record)
        self.assertTrue(record["attempts"])
        run_dir = os.path.join(
            self.repo, "ai-reviews", "runs", record["run_id"]
        )
        for name in ("report.md", "attempt-1.json", "attempt-1.stdout",
                     "attempt-1.stderr"):
            self.assertTrue(
                os.path.exists(os.path.join(run_dir, name)), name
            )
        self.assertTrue(
            os.path.exists(os.path.join(self.repo, "ai-reviews", "latest.md"))
        )

    def test_evidence_files_are_private(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 0, result.stderr)
        record = self.latest_run_record()
        run_dir = os.path.join(
            self.repo, "ai-reviews", "runs", record["run_id"]
        )

        def is_owner_only(path):
            mode = stat.S_IMODE(os.stat(path).st_mode)
            return mode & 0o077 == 0

        self.assertTrue(is_owner_only(run_dir), run_dir)
        for name in ("attempt-1.stdout", "attempt-1.stderr"):
            path = os.path.join(run_dir, name)
            self.assertTrue(is_owner_only(path), path)


class TestDurableMergeWithFixesIntake(GateTestCase):
    def durable_updater(self, exit_code=0):
        log_path = os.path.join(self.root, "durable-updates.log")
        updater = self.write_fake_bin(
            "#!/usr/bin/env bash\n"
            'printf "%%s\\n" "$AI_REVIEW_HEAD_COMMIT" >> "$FAKE_DURABLE_LOG"\n'
            "exit %d\n" % exit_code,
            name="durable-updater",
        )
        self.base_env["FAKE_DURABLE_LOG"] = log_path
        return updater, log_path

    def durable_calls(self, log_path):
        try:
            with open(log_path, "r", encoding="utf-8") as handle:
                return [line.strip() for line in handle if line.strip()]
        except OSError:
            return []

    def payload_updater(self):
        """A fake updater that preserves what it is actually given."""
        payload_path = os.path.join(self.root, "durable-payload.json")
        updater = self.write_fake_bin(
            "#!/usr/bin/env bash\n"
            'cat > "$FAKE_DURABLE_PAYLOAD"\n'
            "exit 0\n",
            name="payload-updater",
        )
        self.base_env["FAKE_DURABLE_PAYLOAD"] = payload_path
        return updater, payload_path

    def test_updater_receives_the_parsed_findings_on_stdin(self):
        fake = self.write_fake_bin(result_script(MERGE_WITH_FIXES_RESULT))
        updater, payload_path = self.payload_updater()
        self.write_profile(
            fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 0, result.stderr)

        with open(payload_path, "r", encoding="utf-8") as handle:
            raw = handle.read()
        payload = json.loads(raw)

        self.assertEqual(payload["head"], head)
        self.assertEqual(payload["base"], base)
        self.assertEqual(payload["verdict"], "MERGE-WITH-FIXES")
        self.assertEqual(payload["risk_class"], "general")

        # The run id is known before evidence is finalized, so a consumer can
        # mint durable finding ids now that match the ones a later scrape of
        # the finalized run would produce.
        record = self.latest_run_record()
        self.assertEqual(payload["run_id"], record["run_id"])
        self.assertEqual(payload["started_utc"], record["started_utc"])

        expected = MERGE_WITH_FIXES_RESULT["findings"][0]
        self.assertEqual(len(payload["findings"]), 1)
        finding = payload["findings"][0]
        for key in ("severity", "file", "line", "trigger", "consequence", "fix"):
            self.assertEqual(finding[key], expected[key], key)

        # The reviewer's surrounding prose is untrusted and must never be
        # copied into a payload a repository will persist.
        self.assertNotIn("some review prose", raw)
        self.assertNotIn("raw_text", raw)
        self.assertNotIn("REVIEW-RESULT-BEGIN", raw)

    def test_updater_still_receives_the_legacy_head_commit_variable(self):
        fake = self.write_fake_bin(result_script(MERGE_WITH_FIXES_RESULT))
        log_path = os.path.join(self.root, "durable-updates.log")
        updater = self.write_fake_bin(
            "#!/usr/bin/env bash\n"
            'printf "%s\\n" "$CATALOG_COMMIT" >> "$FAKE_DURABLE_LOG"\n'
            "exit 0\n",
            name="legacy-name-updater",
        )
        self.base_env["FAKE_DURABLE_LOG"] = log_path
        self.write_profile(
            fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)

        # An updater written against the pre-2.2.0 name must not silently
        # receive an empty commit while it migrates.
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.durable_calls(log_path), [head])

    def test_payload_carries_the_full_finding_set(self):
        crowded = dict(MERGE_WITH_FIXES_RESULT)
        crowded["findings"] = [
            {
                "severity": "SHOULD-FIX",
                "file": "file-%d.py" % index,
                "line": index + 1,
                "trigger": "trigger %d %s" % (index, "x" * 200),
                "consequence": "consequence %d" % index,
                "fix": "fix %d" % index,
            }
            for index in range(40)
        ]
        fake = self.write_fake_bin(result_script(crowded))
        updater, payload_path = self.payload_updater()
        self.write_profile(
            fake,
            extra=(
                "AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater
                + "AI_REVIEW_MAX_PRIOR_REPORT_BYTES=2000\n"
            ),
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 0, result.stderr)

        with open(payload_path, "r", encoding="utf-8") as handle:
            payload = json.loads(handle.read())

        # Reviewer stdout is already bounded by max_output_bytes. Re-capping
        # intake with the unrelated prior-report budget would drop accepted
        # findings from the tracked artifact, which is the one thing intake
        # exists to prevent.
        self.assertEqual(len(payload["findings"]), 40)

    def test_fresh_merge_with_fixes_updates_intake_before_cache(self):
        fake = self.write_fake_bin(result_script(MERGE_WITH_FIXES_RESULT))
        updater, log_path = self.durable_updater()
        self.write_profile(
            fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.durable_calls(log_path), [head])
        self.assertEqual(len(self.cache_entries()), 1)

    def test_updater_failure_is_inconclusive_and_does_not_cache(self):
        fake = self.write_fake_bin(result_script(MERGE_WITH_FIXES_RESULT))
        updater, log_path = self.durable_updater(exit_code=9)
        self.write_profile(
            fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)

        self.assertEqual(result.returncode, 2)
        self.assertIn("durable merge-with-fixes intake failed", result.stderr)
        self.assertEqual(self.durable_calls(log_path), [head])
        self.assertEqual(self.cache_entries(), [])
        record = self.latest_run_record()
        self.assertEqual(
            record["decision"]["reason_code"], "durable_intake_failed"
        )
        self.assertEqual(
            record["reviewer_decision"]["verdict"], "MERGE-WITH-FIXES"
        )
        self.assertFalse(
            os.path.exists(
                os.path.join(self.repo, "ai-reviews", "state", "main.json")
            )
        )

    def test_safe_and_exact_cache_reuse_do_not_update_intake(self):
        updater, log_path = self.durable_updater()
        safe_fake = self.write_fake_bin(
            result_script(SAFE_RESULT), name="safe-reviewer"
        )
        self.write_profile(
            safe_fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        base = self.git_out("rev-parse", "HEAD")
        safe_head = self.commit_change()

        safe = self.run_gate("review", "--base", base, "--head", safe_head)
        self.assertEqual(safe.returncode, 0, safe.stderr)
        self.assertEqual(self.durable_calls(log_path), [])

        merge_fake = self.write_fake_bin(
            result_script(MERGE_WITH_FIXES_RESULT), name="merge-reviewer"
        )
        self.write_profile(
            merge_fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        merge_head = self.commit_change("later.txt", "later\n", "Later")
        first = self.run_gate("review", "--base", base, "--head", merge_head)
        repeat = self.run_gate("review", "--base", base, "--head", merge_head)

        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(repeat.returncode, 0, repeat.stderr)
        self.assertEqual(self.durable_calls(log_path), [merge_head])

    def test_blocking_decision_bypasses_intake_and_still_caches(self):
        fake = self.write_fake_bin(result_script(BLOCKING_RESULT))
        updater, log_path = self.durable_updater()
        self.write_profile(
            fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)

        # A blocking review persists through its cache entry and the
        # acknowledgement flow; a broken updater must not destroy it.
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertEqual(self.durable_calls(log_path), [])
        self.assertEqual(len(self.cache_entries()), 1)

    def test_noisy_updater_output_does_not_fail_intake(self):
        log_path = os.path.join(self.root, "durable-updates.log")
        updater = self.write_fake_bin(
            "#!/usr/bin/env bash\n"
            'printf "%s\\n" "$AI_REVIEW_HEAD_COMMIT" >> "$FAKE_DURABLE_LOG"\n'
            "head -c 100000 /dev/zero | tr '\\0' 'x'\n"
            "exit 0\n",
            name="durable-updater",
        )
        self.base_env["FAKE_DURABLE_LOG"] = log_path
        fake = self.write_fake_bin(result_script(MERGE_WITH_FIXES_RESULT))
        self.write_profile(
            fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.durable_calls(log_path), [head])
        self.assertEqual(len(self.cache_entries()), 1)

    def test_version_1_profile_cannot_enable_intake(self):
        fake = self.write_fake_bin(result_script(MERGE_WITH_FIXES_RESULT))
        updater, log_path = self.durable_updater()
        self.write_profile(
            fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        profile_path = os.path.join(self.repo, ".review-hooks.conf")
        with open(profile_path, "r", encoding="utf-8") as handle:
            profile = handle.read()
        self.write_file(profile_path, profile.replace(
            "REVIEW_HOOKS_PROFILE_VERSION=2", "REVIEW_HOOKS_PROFILE_VERSION=1"
        ))
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)

        self.assertEqual(result.returncode, 2)
        self.assertIn("version 2", result.stderr)
        self.assertEqual(self.call_count(), 0)
        self.assertEqual(self.durable_calls(log_path), [])

    def test_enabling_intake_invalidates_an_older_cached_decision(self):
        fake = self.write_fake_bin(result_script(MERGE_WITH_FIXES_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()
        first = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(first.returncode, 0, first.stderr)

        updater, log_path = self.durable_updater()
        self.write_profile(
            fake,
            extra="AI_REVIEW_MERGE_WITH_FIXES_COMMAND='%s'\n" % updater,
        )
        second = self.run_gate("review", "--base", base, "--head", head)

        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(self.call_count(), 2)
        self.assertEqual(self.durable_calls(log_path), [head])


class TestBlockingFlow(GateTestCase):
    def test_blocking_review_caches_and_binds_acknowledgement(self):
        fake = self.write_fake_bin(result_script(BLOCKING_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        first = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(first.returncode, 1, first.stderr)
        self.assertEqual(self.call_count(), 1)

        # A repeated push must not buy the same blocking answer again.
        repeat = self.run_gate(
            "check-push", "--updates-file", self.updates_file(head, base)
        )
        self.assertEqual(repeat.returncode, 1)
        self.assertEqual(self.call_count(), 1)

        # The free-text environment override must not work in version 2.
        env_override = self.run_gate(
            "check-push",
            "--updates-file", self.updates_file(head, base),
            env_extra={"AI_REVIEW_HUMAN_ACK": "exported forever"},
        )
        self.assertEqual(env_override.returncode, 1)

        # The gate prints the exact report to acknowledge; follow it.
        match = re.search(r"--report (\S+)", repeat.stderr)
        self.assertIsNotNone(match, repeat.stderr)
        report_path = match.group(1)

        ack = self.run_gate(
            "acknowledge", "--report", report_path, "--reason", "TICKET-42"
        )
        self.assertEqual(ack.returncode, 0, ack.stderr)

        accepted = self.run_gate(
            "check-push", "--updates-file", self.updates_file(head, base)
        )
        self.assertEqual(accepted.returncode, 0, accepted.stderr)
        self.assertEqual(self.call_count(), 1)

        # The acknowledgement binds to that exact tree; new work re-blocks.
        head2 = self.commit_change("second.txt", "more\n", "Second")
        blocked_again = self.run_gate(
            "check-push", "--updates-file", self.updates_file(head2, base)
        )
        self.assertEqual(blocked_again.returncode, 1, blocked_again.stderr)
        self.assertEqual(self.call_count(), 2)

    def test_acknowledge_refuses_altered_report(self):
        fake = self.write_fake_bin(result_script(BLOCKING_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()
        self.run_gate("review", "--base", base, "--head", head)

        run_id = self.run_dirs()[-1]
        report_path = os.path.join(
            self.repo, "ai-reviews", "runs", run_id, "report.md"
        )
        with open(report_path, "a", encoding="utf-8") as handle:
            handle.write("\nedited after the fact\n")

        ack = self.run_gate(
            "acknowledge", "--report", report_path, "--reason", "TICKET-43"
        )
        self.assertEqual(ack.returncode, 2)
        self.assertIn("altered", ack.stderr)


class TestInconclusiveAndInvalid(GateTestCase):
    def test_inconclusive_verdict_never_caches(self):
        fake = self.write_fake_bin(result_script(INCONCLUSIVE_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.cache_entries(), [])
        record = self.latest_run_record()
        self.assertEqual(record["decision"]["verdict"], "INCONCLUSIVE")

    def test_invalid_result_json_cannot_enter_cache(self):
        script = (
            "#!/usr/bin/env bash\n"
            "cat >/dev/null\n"
            'echo "$$" >> "$FAKE_CALL_LOG"\n'
            "cat <<'ENVELOPE'\n"
            "%s\n"
            "ENVELOPE\n"
        ) % cli_envelope(
            "REVIEW-RESULT-BEGIN\n"
            '{"schema_version": 1, "verdict": "SAFE"\n'
            "REVIEW-RESULT-END"
        )
        fake = self.write_fake_bin(script)
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.cache_entries(), [])
        record = self.latest_run_record()
        self.assertEqual(record["decision"]["reason_code"], "invalid_result")


class TestCacheKeyInputs(GateTestCase):
    def test_policy_prompt_or_model_change_misses_cache(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        self.assertEqual(
            self.run_gate("review", "--base", base, "--head", head).returncode, 0
        )
        self.assertEqual(self.call_count(), 1)

        # Same source, same policy: cache hit.
        self.assertEqual(
            self.run_gate("review", "--base", base, "--head", head).returncode, 0
        )
        self.assertEqual(self.call_count(), 1)

        # A policy change must miss.
        self.write_profile(
            fake, extra="AI_REVIEW_PRODUCT_NAME='another product'\n"
        )
        self.assertEqual(
            self.run_gate("review", "--base", base, "--head", head).returncode, 0
        )
        self.assertEqual(self.call_count(), 2)

        # A reviewer identity change must miss.
        self.write_profile(
            fake,
            extra=(
                "AI_REVIEW_PRODUCT_NAME='another product'\n"
                "AI_REVIEW_MODEL='different-model'\n"
            ),
        )
        self.assertEqual(
            self.run_gate("review", "--base", base, "--head", head).returncode, 0
        )
        self.assertEqual(self.call_count(), 3)

    def test_template_text_change_misses_cache(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        self.assertEqual(
            self.run_gate("review", "--base", base, "--head", head).returncode, 0
        )
        self.assertEqual(self.call_count(), 1)

        # An unmodified copy of the runtime shares the cache.
        copy_root = os.path.join(self.root, "gate-copy")
        shutil.copytree(
            MODULE_ROOT,
            copy_root,
            ignore=shutil.ignore_patterns("__pycache__", "tests"),
        )
        copy_gate = os.path.join(copy_root, "bin", "review-gate")
        self.assertEqual(
            self.run_gate(
                "review", "--base", base, "--head", head, gate=copy_gate
            ).returncode,
            0,
        )
        self.assertEqual(self.call_count(), 1)

        # Any edit to the prompt template module must miss the cache.
        prompts_path = os.path.join(copy_root, "review_gate", "prompts.py")
        with open(prompts_path, "a", encoding="utf-8") as handle:
            handle.write("\n# template edited by cache test\n")
        self.assertEqual(
            self.run_gate(
                "review", "--base", base, "--head", head, gate=copy_gate
            ).returncode,
            0,
        )
        self.assertEqual(self.call_count(), 2)

    def test_unnamed_model_refuses_paid_attempt(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake, extra="AI_REVIEW_MODEL=''\n")
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.call_count(), 0)
        record = self.latest_run_record()
        self.assertEqual(record["decision"]["reason_code"], "model_unnamed")

    def test_model_flag_reaches_every_launch(self):
        prompt_copy = os.path.join(self.root, "argv-check")
        script = (
            "#!/usr/bin/env bash\n"
            "cat >/dev/null\n"
            'echo "$$" >> "$FAKE_CALL_LOG"\n'
            'printf "%%s\\n" "$@" > "%s"\n'
            "cat <<'ENVELOPE'\n"
            "%s\n"
            "ENVELOPE\n"
        ) % (prompt_copy, cli_envelope(
            "REVIEW-RESULT-BEGIN\n%s\nREVIEW-RESULT-END"
            % json.dumps(SAFE_RESULT)
        ))
        fake = self.write_fake_bin(script)
        self.write_profile(fake, extra=(
            "AI_REVIEW_MAX_ATTEMPTS=2\n"
            "AI_REVIEW_RETRYABLE_FAILURES='startup_transport'\n"
            "AI_REVIEW_STARTUP_EXIT_CODES='7'\n"
            "AI_REVIEW_MAX_BUDGET_USD=2.00\n"
        ))
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 0, result.stderr)
        with open(prompt_copy, "r", encoding="utf-8") as handle:
            argv = handle.read().splitlines()
        self.assertIn("--model", argv)
        self.assertIn("test-model", argv)
        self.assertIn("--output-format", argv)
        self.assertIn("--max-budget-usd", argv)
        # Attempt caps split the run cap; two reserved attempts on a
        # 2.00 budget give each launch a 1.00 cap.
        cap = argv[argv.index("--max-budget-usd") + 1]
        self.assertEqual(cap, "1.0000")


class TestRefusals(GateTestCase):
    def test_personal_quota_requires_opt_in(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake, extra="AI_REVIEW_CREDENTIAL_SCOPE=personal\n")
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        refused = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(refused.returncode, 2)
        self.assertEqual(self.call_count(), 0)
        record = self.latest_run_record()
        self.assertEqual(
            record["decision"]["reason_code"], "personal_quota_refused"
        )

        allowed = self.run_gate(
            "review", "--base", base, "--head", head,
            env_extra={"AI_REVIEW_ALLOW_PERSONAL_QUOTA": "1"},
        )
        self.assertEqual(allowed.returncode, 0, allowed.stderr)
        self.assertEqual(self.call_count(), 1)

    def test_sensitive_paths_are_refused_before_any_call(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change(".env", "SECRET=1\n", "Sensitive")

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.call_count(), 0)
        record = self.latest_run_record()
        self.assertEqual(record["decision"]["reason_code"], "sensitive_paths")

    def test_multi_branch_push_is_refused(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        head = self.commit_change()
        updates = os.path.join(self.root, "multi.txt")
        self.write_file(updates, (
            "refs/heads/main %s refs/heads/main %s\n"
            "refs/heads/other %s refs/heads/other %s\n"
        ) % (head, "0" * 40, head, "0" * 40))

        result = self.run_gate("check-push", "--updates-file", updates)
        self.assertEqual(result.returncode, 2)
        self.assertIn("one branch", result.stderr)
        self.assertEqual(self.call_count(), 0)
        record = self.latest_run_record()
        self.assertEqual(
            record["decision"]["reason_code"], "invalid_push_updates"
        )


class TestSkipBinding(GateTestCase):
    def test_skip_binds_to_exact_head(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake, extra="AI_REVIEW_PUSH_MODE=verify\n")
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        legacy_style = self.run_gate(
            "check-push",
            "--updates-file", self.updates_file(head, base),
            env_extra={
                "SKIP_AI_REVIEW": "1",
                "AI_REVIEW_HUMAN_ACK": "emergency",
            },
        )
        self.assertEqual(legacy_style.returncode, 2)

        bound = self.run_gate(
            "check-push",
            "--updates-file", self.updates_file(head, base),
            env_extra={
                "SKIP_AI_REVIEW": head[:12],
                "AI_REVIEW_HUMAN_ACK": "emergency TICKET-9",
            },
        )
        self.assertEqual(bound.returncode, 0, bound.stderr)
        self.assertEqual(self.call_count(), 0)
        record = self.latest_run_record()
        self.assertEqual(record["decision"]["verdict"], "SKIPPED")

        # The same exported value must not skip the next push.
        head2 = self.commit_change("more.txt", "more\n", "More")
        stale = self.run_gate(
            "check-push",
            "--updates-file", self.updates_file(head2, base),
            env_extra={
                "SKIP_AI_REVIEW": head[:12],
                "AI_REVIEW_HUMAN_ACK": "emergency TICKET-9",
            },
        )
        self.assertEqual(stale.returncode, 2)


class TestSpendLedger(GateTestCase):
    def test_rolling_limit_refuses_paid_launch(self):
        fake = self.write_fake_bin(
            result_script(SAFE_RESULT, total_cost_usd=1.5)
        )
        self.write_profile(
            fake,
            extra=(
                "AI_REVIEW_ROLLING_SPEND_LIMIT_USD=3.00\n"
                "AI_REVIEW_MAX_BUDGET_USD=2.00\n"
            ),
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        first = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(self.call_count(), 1)

        ledger_path = os.path.join(
            self.repo, "ai-reviews", "spend", "ledger.jsonl"
        )
        with open(ledger_path, "r", encoding="utf-8") as handle:
            entries = [json.loads(line) for line in handle if line.strip()]
        # The 2.00 reservation settled down to the reported 1.50.
        self.assertEqual(len(entries), 2)
        self.assertEqual(entries[0]["actual_usd"], None)
        self.assertEqual(entries[1]["actual_usd"], 1.5)

        # A second distinct tree wants 2.00 more; 1.50 + 2.00 > 3.00.
        head2 = self.commit_change("more.txt", "more\n", "More")
        second = self.run_gate("review", "--base", base, "--head", head2)
        self.assertEqual(second.returncode, 2)
        self.assertEqual(self.call_count(), 1)
        record = self.latest_run_record()
        self.assertEqual(record["decision"]["reason_code"], "spend_limit")

    def test_settled_actual_spend_frees_the_rolling_window(self):
        # Twelve unreconciled 2.00 reservations once filled a 25.00
        # window with phantom spend; settled real cost must not.
        fake = self.write_fake_bin(
            result_script(SAFE_RESULT, total_cost_usd=0.05)
        )
        self.write_profile(
            fake,
            extra=(
                "AI_REVIEW_ROLLING_SPEND_LIMIT_USD=3.00\n"
                "AI_REVIEW_MAX_BUDGET_USD=2.00\n"
            ),
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        first = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(first.returncode, 0, first.stderr)

        # 0.05 settled + 2.00 reserved stays under 3.00, so a second
        # distinct tree still buys a review.
        head2 = self.commit_change("more.txt", "more\n", "More")
        second = self.run_gate("review", "--base", base, "--head", head2)
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(self.call_count(), 2)

    def test_attempt_caps_floor_so_their_sum_stays_under_the_run_cap(self):
        prompt_copy = os.path.join(self.root, "argv-floor-check")
        script = (
            "#!/usr/bin/env bash\n"
            "cat >/dev/null\n"
            'echo "$$" >> "$FAKE_CALL_LOG"\n'
            'printf "%%s\\n" "$@" > "%s"\n'
            "cat <<'ENVELOPE'\n"
            "%s\n"
            "ENVELOPE\n"
        ) % (prompt_copy, cli_envelope(
            "REVIEW-RESULT-BEGIN\n%s\nREVIEW-RESULT-END"
            % json.dumps(SAFE_RESULT)
        ))
        fake = self.write_fake_bin(script)
        self.write_profile(fake, extra=(
            "AI_REVIEW_MAX_ATTEMPTS=2\n"
            "AI_REVIEW_RETRYABLE_FAILURES='startup_transport'\n"
            "AI_REVIEW_STARTUP_EXIT_CODES='7'\n"
            "AI_REVIEW_MAX_BUDGET_USD=2.0001\n"
        ))
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 0, result.stderr)
        with open(prompt_copy, "r", encoding="utf-8") as handle:
            argv = handle.read().splitlines()
        cap = float(argv[argv.index("--max-budget-usd") + 1])
        self.assertLessEqual(cap * 2, 2.0001)

    def test_non_finite_budget_is_refused(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(
            fake, extra="AI_REVIEW_ROLLING_SPEND_LIMIT_USD=nan\n"
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.call_count(), 0)

    def test_spend_is_reserved_before_launch_even_when_the_run_fails(self):
        script = (
            "#!/usr/bin/env bash\n"
            'echo "$$" >> "$FAKE_CALL_LOG"\n'
            "exit 9\n"
        )
        fake = self.write_fake_bin(script)
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 2)
        ledger_path = os.path.join(
            self.repo, "ai-reviews", "spend", "ledger.jsonl"
        )
        with open(ledger_path, "r", encoding="utf-8") as handle:
            entries = [json.loads(line) for line in handle if line.strip()]
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["assigned_usd"], 2.0)

    def test_unlaunched_attempt_settles_to_zero(self):
        missing_bin = os.path.join(self.root, "no-such-binary")
        self.write_profile(missing_bin)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 2)
        ledger_path = os.path.join(
            self.repo, "ai-reviews", "spend", "ledger.jsonl"
        )
        with open(ledger_path, "r", encoding="utf-8") as handle:
            entries = [json.loads(line) for line in handle if line.strip()]
        self.assertEqual(len(entries), 2)
        self.assertEqual(entries[0]["assigned_usd"], 2.0)
        self.assertIsNone(entries[0]["actual_usd"])
        self.assertEqual(entries[1]["actual_usd"], 0.0)

    def test_unlaunched_attempts_do_not_exhaust_the_rolling_limit(self):
        missing_bin = os.path.join(self.root, "no-such-binary")
        self.write_profile(
            missing_bin,
            extra="AI_REVIEW_ROLLING_SPEND_LIMIT_USD=3.00\n",
        )
        base = self.git_out("rev-parse", "HEAD")
        head1 = self.commit_change()

        first = self.run_gate("review", "--base", base, "--head", head1)
        self.assertEqual(first.returncode, 2)

        head2 = self.commit_change("more.txt", "more\n", "More")
        second = self.run_gate("review", "--base", base, "--head", head2)
        self.assertEqual(second.returncode, 2)

        # Two phantom "reserve $2, settle $0" runs left no real spend
        # behind, so a third distinct tree still buys a review.
        working_fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(
            working_fake,
            extra="AI_REVIEW_ROLLING_SPEND_LIMIT_USD=3.00\n",
        )
        head3 = self.commit_change("even-more.txt", "even more\n", "More still")
        third = self.run_gate("review", "--base", base, "--head", head3)
        self.assertEqual(third.returncode, 0, third.stderr)

    def test_launched_but_silent_attempt_keeps_the_full_reservation(self):
        script = (
            "#!/usr/bin/env bash\n"
            'echo "$$" >> "$FAKE_CALL_LOG"\n'
            "exit 9\n"
        )
        fake = self.write_fake_bin(script)
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 2)
        ledger_path = os.path.join(
            self.repo, "ai-reviews", "spend", "ledger.jsonl"
        )
        with open(ledger_path, "r", encoding="utf-8") as handle:
            entries = [json.loads(line) for line in handle if line.strip()]
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["assigned_usd"], 2.0)
        self.assertIsNone(entries[0]["actual_usd"])
        self.assertFalse(
            any(entry.get("actual_usd") == 0.0 for entry in entries)
        )

    def test_old_ledger_entries_age_out(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(
            fake,
            extra=(
                "AI_REVIEW_ROLLING_SPEND_LIMIT_USD=3.00\n"
                "AI_REVIEW_MAX_BUDGET_USD=2.00\n"
            ),
        )
        ledger_path = os.path.join(
            self.repo, "ai-reviews", "spend", "ledger.jsonl"
        )
        stale = {
            "timestamp": time.time() - 48 * 3600,
            "run_id": "old",
            "assigned_usd": 2.0,
            "actual_usd": None,
        }
        self.write_file(ledger_path, json.dumps(stale) + "\n")
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.call_count(), 1)


class TestIncrementalState(GateTestCase):
    def test_incremental_review_carries_open_findings(self):
        fake = self.write_fake_bin(result_script(BLOCKING_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head1 = self.commit_change()
        self.assertEqual(
            self.run_gate("review", "--base", base, "--head", head1).returncode,
            1,
        )

        prompt_copy = os.path.join(self.root, "prompt-copy.txt")
        head2 = self.commit_change("more.txt", "more\n", "More")
        result = self.run_gate(
            "review", "--base", base, "--head", head2,
            env_extra={"FAKE_PROMPT_COPY": prompt_copy},
        )
        self.assertEqual(result.returncode, 1, result.stderr)
        record = self.latest_run_record()
        self.assertEqual(record["review_from"], head1)
        self.assertTrue(record["incremental"])
        self.assertEqual(record["prior_findings_count"], 1)
        with open(prompt_copy, "r", encoding="utf-8") as handle:
            prompt = handle.read()
        self.assertIn("Open findings", prompt)
        self.assertIn("test trigger", prompt)

    def test_reviewer_change_discards_incremental_state(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head1 = self.commit_change()
        self.assertEqual(
            self.run_gate("review", "--base", base, "--head", head1).returncode,
            0,
        )

        # A new reviewer must not inherit the old reviewer's coverage of
        # base..head1: the follow-up reviews the full range.
        self.write_profile(fake, extra="AI_REVIEW_MODEL='different-model'\n")
        head2 = self.commit_change("more.txt", "more\n", "More")
        result = self.run_gate("review", "--base", base, "--head", head2)
        self.assertEqual(result.returncode, 0, result.stderr)
        record = self.latest_run_record()
        self.assertEqual(record["review_from"], base)
        self.assertFalse(record["incremental"])

    def test_template_text_change_discards_incremental_state(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head1 = self.commit_change()
        self.assertEqual(
            self.run_gate("review", "--base", base, "--head", head1).returncode,
            0,
        )

        # An unmodified copy of the runtime still inherits the coverage.
        copy_root = os.path.join(self.root, "state-gate-copy")
        shutil.copytree(
            MODULE_ROOT,
            copy_root,
            ignore=shutil.ignore_patterns("__pycache__", "tests"),
        )
        copy_gate = os.path.join(copy_root, "bin", "review-gate")
        head2 = self.commit_change("more.txt", "more\n", "More")
        unchanged = self.run_gate(
            "review", "--base", base, "--head", head2, gate=copy_gate
        )
        self.assertEqual(unchanged.returncode, 0, unchanged.stderr)
        record = self.latest_run_record()
        self.assertEqual(record["review_from"], head1)
        self.assertTrue(record["incremental"])

        # Editing the prompt template changes what the reviewer is asked to
        # look for, so coverage of base..head2 must not be inherited: the
        # follow-up reviews the full range under the new template.
        prompts_path = os.path.join(copy_root, "review_gate", "prompts.py")
        with open(prompts_path, "a", encoding="utf-8") as handle:
            handle.write("\n# template edited by incremental state test\n")
        head3 = self.commit_change("third.txt", "third\n", "Third")
        edited = self.run_gate(
            "review", "--base", base, "--head", head3, gate=copy_gate
        )
        self.assertEqual(edited.returncode, 0, edited.stderr)
        record = self.latest_run_record()
        self.assertEqual(record["review_from"], base)
        self.assertFalse(record["incremental"])

    def test_damaged_state_is_ignored(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        self.write_profile(fake)
        self.write_file(
            os.path.join(self.repo, "ai-reviews", "state", "main.json"),
            "{not json",
        )
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()

        result = self.run_gate("review", "--base", base, "--head", head)
        self.assertEqual(result.returncode, 0, result.stderr)
        record = self.latest_run_record()
        self.assertEqual(record["review_from"], base)
        self.assertFalse(record["incremental"])


class TestPolicyValidation(GateTestCase):
    def test_invalid_policy_values_refuse(self):
        fake = self.write_fake_bin(result_script(SAFE_RESULT))
        head = self.commit_change()
        base = self.git_out("rev-parse", "HEAD~1")

        cases = (
            "AI_REVIEW_MAX_ATTEMPTS=3\n",
            "AI_REVIEW_PUSH_MODE=maybe\n",
            "AI_REVIEW_RETRYABLE_FAILURES='anything_goes'\n",
            "AI_REVIEW_MAX_BUDGET_USD=0\n",
        )
        for extra in cases:
            self.write_profile(fake, extra=extra)
            result = self.run_gate("review", "--base", base, "--head", head)
            self.assertEqual(result.returncode, 2, extra)
            self.assertEqual(self.call_count(), 0, extra)


class TestEnvelopeSemantics(GateTestCase):
    """E1 hardening: only the captured success envelope shape can produce
    a decision; every error envelope fails closed under its semantic
    reason, at exit zero and nonzero alike."""

    def envelope_script(self, envelope_text, exit_code=0):
        return (
            "#!/usr/bin/env bash\n"
            "cat >/dev/null\n"
            'echo "$$" >> "$FAKE_CALL_LOG"\n'
            "cat <<'ENVELOPE'\n"
            "%s\n"
            "ENVELOPE\n"
            "exit %d\n"
        ) % (envelope_text, exit_code)

    def fixture_script(self, name, exit_code=0):
        with open(os.path.join(FIXTURES_DIR, name), encoding="utf-8") as fh:
            return self.envelope_script(fh.read(), exit_code)

    def run_review(self, script):
        fake = self.write_fake_bin(script)
        self.write_profile(fake)
        base = self.git_out("rev-parse", "HEAD")
        head = self.commit_change()
        return self.run_gate("review", "--base", base, "--head", head)

    def assert_refused(self, result, reason_code):
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.cache_entries(), [])
        record = self.latest_run_record()
        self.assertEqual(record["decision"]["reason_code"], reason_code)
        return record

    def valid_safe_result_text(self):
        return (
            "prose\nREVIEW-RESULT-BEGIN\n%s\nREVIEW-RESULT-END"
            % json.dumps(SAFE_RESULT)
        )

    def ledger_entries(self):
        path = os.path.join(
            self.repo, "ai-reviews", "spend", "ledger.jsonl"
        )
        with open(path, encoding="utf-8") as handle:
            return [json.loads(line) for line in handle if line.strip()]

    def test_h1_error_envelope_with_valid_result_never_passes(self):
        # Pre-H1, this exact shape passed the gate and entered the
        # decision cache (demonstrated live against the unhardened
        # parser on 2026-08-07).
        script = self.envelope_script(error_envelope(
            api_error_status=429,
            result_text=self.valid_safe_result_text(),
            total_cost_usd=0.002,
        ))
        self.assert_refused(self.run_review(script), "rate_limited")

    def test_captured_success_fixture_still_passes(self):
        result = self.run_review(self.fixture_script("success.json"))
        self.assertEqual(result.returncode, 0)
        self.assertEqual(len(self.cache_entries()), 1)

    def test_error_fixtures_classify_identically_at_both_exit_codes(self):
        # The budget capture really exited 1 and the transport-failure
        # capture died at the gate deadline; a clean fake exit proves
        # the envelope, not the exit code, drives classification.
        cases = [
            ("budget-exhausted.json", "budget_exhausted"),
            ("rate-limited.json", "rate_limited"),
            ("partial-result.json", "provider_error"),
        ]
        for fixture, reason in cases:
            for exit_code in (0, 1):
                with self.subTest(fixture=fixture, exit_code=exit_code):
                    self.setUp()
                    result = self.run_review(
                        self.fixture_script(fixture, exit_code=exit_code)
                    )
                    self.assert_refused(result, reason)

    def test_status_code_branches_classify_semantically(self):
        cases = [
            (401, "authentication_failed"),
            (403, "authentication_failed"),
            (503, "provider_unavailable"),
            (529, "provider_unavailable"),
        ]
        for status, reason in cases:
            with self.subTest(status=status):
                self.setUp()
                script = self.envelope_script(error_envelope(
                    api_error_status=status,
                    result_text=self.valid_safe_result_text(),
                ))
                self.assert_refused(self.run_review(script), reason)

    def test_truncated_envelope_is_invalid_envelope(self):
        with open(os.path.join(FIXTURES_DIR, "success.json"),
                  encoding="utf-8") as fh:
            truncated = fh.read()[:200]
        result = self.run_review(self.envelope_script(truncated))
        self.assert_refused(result, "invalid_envelope")

    def test_unknown_error_subtype_is_provider_error(self):
        script = self.envelope_script(error_envelope(
            subtype="error_new_unknown_kind"
        ))
        self.assert_refused(self.run_review(script), "provider_error")

    def test_contradictory_fields_fail_closed(self):
        # A success claim carrying any error discriminator is never
        # trusted, whichever side of the envelope carries the claim.
        contradictions = [
            # is_error true with a success subtype.
            {"is_error": True},
            # Claimed success with a provider error status.
            {"api_error_status": 429},
            # Claimed success with an error terminal reason.
            {"terminal_reason": "budget_exhausted"},
        ]
        for overrides in contradictions:
            with self.subTest(**overrides):
                self.setUp()
                envelope = {
                    "type": "result", "subtype": "success",
                    "is_error": False, "terminal_reason": "completed",
                    "result": self.valid_safe_result_text(),
                    "total_cost_usd": 0.002,
                }
                envelope.update(overrides)
                script = self.envelope_script(json.dumps(envelope))
                self.assert_refused(
                    self.run_review(script), "invalid_envelope"
                )

    def test_success_without_discriminators_fails_closed(self):
        # The pre-hardening minimal shape: result present, no subtype
        # or is_error. No longer trusted.
        script = self.envelope_script(json.dumps({
            "type": "result",
            "result": self.valid_safe_result_text(),
            "total_cost_usd": 0.002,
        }))
        self.assert_refused(self.run_review(script), "invalid_envelope")

    def test_error_envelope_cost_settles_reservation(self):
        script = self.envelope_script(error_envelope(
            api_error_status=429, total_cost_usd=0.002,
        ))
        self.assert_refused(self.run_review(script), "rate_limited")
        entries = self.ledger_entries()
        self.assertEqual(len(entries), 2)
        self.assertIsNone(entries[0]["actual_usd"])
        self.assertAlmostEqual(entries[1]["actual_usd"], 0.002)

    def test_missing_cost_keeps_assigned_reservation(self):
        script = self.envelope_script(error_envelope(
            api_error_status=429, total_cost_usd=None,
        ))
        self.assert_refused(self.run_review(script), "rate_limited")
        entries = self.ledger_entries()
        # No settlement: the conservative reservation stands.
        self.assertEqual(len(entries), 1)
        self.assertIsNone(entries[0]["actual_usd"])
        self.assertEqual(entries[0]["assigned_usd"], 2.0)


if __name__ == "__main__":
    unittest.main()
